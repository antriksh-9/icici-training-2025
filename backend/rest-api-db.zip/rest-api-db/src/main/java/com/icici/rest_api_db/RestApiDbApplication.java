package com.icici.rest_api_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiDbApplication.class, args);
	}

}
